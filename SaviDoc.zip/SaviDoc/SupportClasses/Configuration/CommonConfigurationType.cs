﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Savian.SaviDoc.SupportClasses.Configuration
{
    public class CommonConfigurationType
    {
        public List<TagSetElement> Tags { get; set; } = new List<TagSetElement>();
    }
}
